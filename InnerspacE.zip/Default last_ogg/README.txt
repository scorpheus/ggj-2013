Config.exe: change resolution
start.exe: launch the game

IF IT CRASH !!

install all exe in the redist folder